# Load Windows Forms for UI elements
Add-Type -AssemblyName System.Windows.Forms

# Function to display a progress bar with virus names
function Show-FakeVirusScan {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Scanning for viruses..."
    $form.Width = 500
    $form.Height = 200
    $form.StartPosition = "CenterScreen"

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Scanning system files..."
    $label.AutoSize = $true
    $label.Top = 20
    $label.Left = 180
    $form.Controls.Add($label)

    $progressBar = New-Object System.Windows.Forms.ProgressBar
    $progressBar.Minimum = 0
    $progressBar.Maximum = 100
    $progressBar.Width = 400
    $progressBar.Height = 20
    $progressBar.Top = 50
    $progressBar.Left = 50
    $form.Controls.Add($progressBar)

    $virusLabel = New-Object System.Windows.Forms.Label
    $virusLabel.Text = ""
    $virusLabel.AutoSize = $true
    $virusLabel.Top = 90
    $virusLabel.Left = 50
    $form.Controls.Add($virusLabel)

    $form.Show()
    $form.Refresh()

    $fakeViruses = @(
        "Trojan.Generic.KJ9812",
        "Worm.Win32.AutoRun.AH",
        "Adware.Agent.AC23",
        "Adware.ClickBait",
        "Ransomware.CryptXXX.4.0",
        "Malware.Backdoor.Win32.Dangerous",
	"Exploit.PDF.CVE-2022-0187",
        "Keylogger.WinLogger.2.1",
	"Spyware.BrowserTracker.Z1",
        "Rootkit.HiddenAccess.5.3",
        "Virus.Win32.Sality.AM"
    )

    for ($i = 0; $i -le 100; $i += 10) {
        Start-Sleep -Milliseconds 500
        $progressBar.Value = $i
        $form.Refresh()

        # Display a random "detected virus"
        if ($i -lt 100) {
            $randomVirus = $fakeViruses | Select-Object -Index (Get-Random -Minimum 0 -Maximum $fakeViruses.Count)
            $virusLabel.Text = "Detected: $randomVirus"
            $form.Refresh()
        }
    }

    $form.Close()
}

# Start with a convincing "installer" splash screen
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("Welcome to the Frog Virus Scanner! Click OK to start scanning.", "Virus Detector")

# Show the fake virus scan progress bar
Show-FakeVirusScan

# Simulate pop-ups about removing detected viruses
$fakeViruses = @(
   "Trojan.Generic.KJ9812",
        "Worm.Win32.AutoRun.AH",
        "Adware.Agent.AC23",
        "Adware.ClickBait",
        "Ransomware.CryptXXX.4.0",
        "Malware.Backdoor.Win32.Dangerous",
	"Exploit.PDF.CVE-2022-0187",
        "Keylogger.WinLogger.2.1",
	"Spyware.BrowserTracker.Z1",
        "Rootkit.HiddenAccess.5.3",
        "Virus.Win32.Sality.AM"
)
for ($i = 1; $i -le 3; $i++) {
    $randomVirus = $fakeViruses | Select-Object -Index (Get-Random -Minimum 0 -Maximum $fakeViruses.Count)
    [System.Windows.MessageBox]::Show("Warning: Detected $randomVirus! Attempting to remove...", "Threat Detected!", 0, [System.Windows.MessageBoxImage]::Warning)
    Start-Sleep -Seconds (Get-Random -Minimum 1 -Maximum 3)
}

# Simulate a "critical error"
[System.Windows.MessageBox]::Show("System error! Critical failure detected during cleanup!", "Critical Error", 0, [System.Windows.MessageBoxImage]::Error)

# Final reveal
[System.Windows.MessageBox]::Show("70 viruses detected. Failed to quarantine 70/70 viruses. Call Admin or IT to delete them.", "Scan Completed", 0, [System.Windows.MessageBoxImage]::Information)
