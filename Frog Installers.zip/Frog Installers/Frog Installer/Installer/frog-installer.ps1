# Load Windows Forms for UI elements
Add-Type -AssemblyName System.Windows.Forms

# Function to display a progress bar
function Show-ProgressBar {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Installing..."
    $form.Width = 400
    $form.Height = 150
    $form.StartPosition = "CenterScreen"

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Installing files..."
    $label.AutoSize = $true
    $label.Top = 20
    $label.Left = 150
    $form.Controls.Add($label)

    $progressBar = New-Object System.Windows.Forms.ProgressBar
    $progressBar.Minimum = 0
    $progressBar.Maximum = 100
    $progressBar.Width = 300
    $progressBar.Height = 20
    $progressBar.Top = 50
    $progressBar.Left = 50
    $form.Controls.Add($progressBar)

    $form.Show()
    $form.Refresh()

    for ($i = 0; $i -le 100; $i += 5) {
        Start-Sleep -Milliseconds 200
        $progressBar.Value = $i
        $form.Refresh()
    }

    $form.Close()
}

# Start with a convincing "installer" splash screen
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("Welcome to the Frog Unblocked Games Installer! Click OK to begin.", "Installer")

# Show the progress bar
Show-ProgressBar

# Simulate random mouse movements
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class MouseMover {
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);
}
"@
for ($j = 1; $j -le 20; $j++) {
    $x = Get-Random -Minimum 0 -Maximum 1920  # Adjust screen width
    $y = Get-Random -Minimum 0 -Maximum 1080  # Adjust screen height
    [MouseMover]::SetCursorPos($x, $y)
    Start-Sleep -Milliseconds 300
}

# Fake mass deletion with varied file names
Write-Host "Deleting critical system files..." -ForegroundColor Red
$fakeFiles = @("C:\Windows\System32\kernel.dll", "C:\Program Files\ImportantApp\app.exe", `
               "C:\Users\Public\Documents\report.docx", "C:\System\Config.sys", `
               "C:\Temp\tempfile.tmp")
for ($k = 1; $k -le 50; $k++) {
    $file = $fakeFiles | Get-Random
    Write-Host "Deleted $file" -ForegroundColor Red
    Start-Sleep -Milliseconds 100
}

# Fake shutdown alert
[System.Windows.MessageBox]::Show("Virus infiltrated! Shutting down and quarantining in 10 seconds!", "Critical Error", 0, [System.Windows.MessageBoxImage]::Error)
Start-Sleep -Seconds 10

# Final reveal
[System.Windows.MessageBox]::Show("System shutdown ignored. Failed to detain virus!", "Install Completed", 0, [System.Windows.MessageBoxImage]::Information)
